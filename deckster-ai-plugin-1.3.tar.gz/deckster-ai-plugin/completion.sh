#!/bin/bash
if ! pgrep -f deckster-ai-plugin.py >/dev/null; then
  /opt/homebrew/opt/deckster-ai/libexec/bin/python /opt/homebrew/opt/deckster-ai/libexec/deckster-ai-plugin.py &
fi
